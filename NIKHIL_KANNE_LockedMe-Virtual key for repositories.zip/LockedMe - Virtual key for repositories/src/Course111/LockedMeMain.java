package Course111;

public class LockedMeMain {
	

		public static void main(String[] args) {
			
			// Create "main" folder if not present in current folder structure
			simplilearn_project1.createMainFolderIfNotPresent("main");
			
			MenuOptions.printWelcomeScreen("LockedMe", "Nikhil");
			
			HandleOptions.handleWelcomeScreenInput();
		}

		
	}

